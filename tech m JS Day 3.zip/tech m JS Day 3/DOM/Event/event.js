// function greet() {
//   document.write("Javascript is easy!!! ");
// }





//to create element multiple times
// function elementCreation() {
//   var element = document.createElement("h2");
//   element.textContent = "TechM";
//   document.body.appendChild(element);
// }




//to create element only once
// var element = document.createElement("p");
// document.body.appendChild(element);

// function elementCreation() {
//   element.textContent = "Javascript Workshop";
// }







//to print data in console by clicking on a text
// function showData() {
//   let ele = document.getElementById("show");
//   console.log(ele.textContent);
// }
