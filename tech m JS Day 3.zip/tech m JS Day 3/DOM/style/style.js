(function () {
    var element = document.getElementById("demo");
    element.style.color = 'blue';
    element.style.fontSize = '30px';
    element.style.backgroundColor = 'silver';

}());




//to add multiple css properties in javascript using a id and classname
//where you write multiple css properties with different class name
var deco = document.getElementById('sam');
deco.className = 'add';





//to add multiple class names we use classList property
var x = document.getElementById('test');
x.classList = 'add header';













