// var date= new Date();
// document.write(date);


// var cd= new Date(2020,11,25,3);
// document.write(cd);







// setTimeout(function(){
//    document.write('Hello Welcome to Sessions')
// }, 3000);






//Eg:1 setTimeout Time delay:
   setTimeout(function(){
   var date = new Date().toLocaleTimeString();
   var x =  document.getElementById('demo');
   x.innerHTML = date;
   },5000);

// Note: 
//innerHTML : it mainly helps in overriding the blocks. {}




//Eg: 2 
// setTimeout(function(){
//     console.log('HELLO PEOPLE!!! ');
// },4000);







// setInterval(function(){
//     var date = new Date().toLocaleTimeString();
//   var x=  document.getElementById('demo');
//   x.innerHTML=date;
 
//  },1000);



 






//date object methods
// var todaysdate = new  Date();
// document.write('todays date is', todaysdate);

// console.log('day',todaysdate.getDay());
// console.log('year',todaysdate.getFullYear());
// console.log('date',todaysdate.getDate());
// console.log('hours',todaysdate.getHours())

















