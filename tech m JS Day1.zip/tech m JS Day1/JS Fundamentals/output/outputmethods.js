// pop up output methods
alert('Hello Im a Alert Message');

confirm('hello Im confirm message!!')

var isBoss = confirm('Are you a Boss..?');
alert(isBoss);

prompt('Hello im A prompt msg');

// debugger tool
console.log('Im A Console Message check in Console');


// Render the data on UI(user interface)
document.write('Hello Im A Document msg check in browser')


