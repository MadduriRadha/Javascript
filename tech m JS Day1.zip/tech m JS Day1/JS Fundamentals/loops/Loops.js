//for loop
var i;
for(i=0;i<10;i++){
    document.write('Hello'+ '<br/>')
}

//while loop
var x = 1;
while(x<=4){
    document.write('value of x:' + x + '<br/>')
    x++;
}

//do while 
var x = 21;
do {
    document.write('value of x:' + x + '<br/>');
    x++;
} while(x < 20);

