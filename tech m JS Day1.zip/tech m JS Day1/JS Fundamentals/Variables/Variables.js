//can declare two variables at once
var admin, name;
name = 'john';
admin = name;
alert(admin);



// var name = "Smith";
// alert(name);