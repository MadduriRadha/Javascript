//primitive Datatypes

//Number
var a = 10.1;
console.log('the 10 is', typeof a); //number

// //String
var str = "Qspiders",
    str2 = 'Jspiders';

console.log('the qspiders is a', typeof str); //string
console.log('the Jspiders is a', typeof str2); //string
console.log(`Welcome to ${str}`); //welcome to qspiders   //backticks `` (template literals : es6)  ${str}: interpolation

// //boolean
var x = true;
console.log('the boolean type is', typeof x);

var isGreater = 4 > 1;
console.log('the value of 4 > 1 is ', isGreater);

// //null
var x1 = null;
console.log('the value is', typeof x1); //object

// //undefined
var s1;
console.log('message one', s1);

var s2 = 'qwerty';
s2 = undefined;
console.log('message two', s2);

