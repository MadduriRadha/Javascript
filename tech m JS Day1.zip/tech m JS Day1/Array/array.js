var arr = ['java', 'sql', 'react', 'nodejs', 'jsp', 'flutter'];

//to display all array elements
console.log('the array elements are', arr);

//to retrieve the array elements using index value
console.log('the element in index 3 is', arr[3]);

//to find the length of array elements
console.log('the array length is', arr.length);

// //to replace a new element 
console.log('replacing element is', arr[2] = 'Mongo DB');
console.log('after replacing the new element', arr);

//Adding the new array element
console.log('the new element is', arr[6] = 'Jquery');
console.log('After new element', arr);
console.log('new length of array', arr.length);

//Array to string
console.log('String elements are', arr.toString());




